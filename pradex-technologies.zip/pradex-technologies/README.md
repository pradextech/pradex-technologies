# Pradex Technologies — Full-Stack Website

> Complete production-ready website with SQLite database, email notifications, admin dashboard, and one-click deployment to Render.com.

---

## ✨ What's Included

| Layer | Tech | Details |
|---|---|---|
| Frontend | HTML5 / CSS3 / JS | Responsive, animated, API-connected |
| Backend | Node.js + Express | REST API, rate limiting, security headers |
| Database | SQLite (sql.js) | Zero setup, file-based, swap to PostgreSQL easily |
| Email | Nodemailer | Owner alert + client confirmation on every inquiry |
| Admin | SPA Dashboard | Login, view/filter/reply/delete inquiries, edit stats |
| Deploy | Render.com | Free tier, auto-deploy from GitHub |

---

## 🚀 Quick Start (Local)

### 1 — Install

```bash
npm install
```

### 2 — Configure environment

```bash
cp .env.example .env
# Edit .env with your values (see Email Setup below)
```

### 3 — Start

```bash
npm start        # production
npm run dev      # development (auto-reload with nodemon)
```

### 4 — Open

| URL | What |
|---|---|
| http://localhost:3000 | Main website |
| http://localhost:3000/admin | Admin dashboard |
| http://localhost:3000/health | Health check |

**Default admin login:**
- Username: `admin`
- Password: `pradex@2025` ← change in `.env` → `ADMIN_PASSWORD`

---

## 📧 Email Setup (Gmail)

Emails are sent when someone submits the contact form:
1. **Owner** gets a styled HTML alert with the inquiry details and a one-click reply button.
2. **Client** gets a branded confirmation with their reference ID.

**Steps to enable:**

1. Go to your Google account → **Security** → enable **2-Step Verification**
2. Go to → **App passwords** → select "Mail" → generate
3. Copy the 16-character password (no spaces)
4. Add to `.env`:

```env
EMAIL_USER=your_gmail@gmail.com
EMAIL_PASS=abcdabcdabcdabcd   # the 16-char app password
OWNER_EMAIL=pradeep@pradextech.com
```

> **Without email config:** The server still works perfectly — inquiries are saved to the database and logged to the console. Email just won't be sent.

---

## 🗄️ Database

Uses **SQLite via sql.js** (pure JavaScript — no native compilation needed). The database file is saved to `db/pradex.sqlite`.

### Tables

| Table | Purpose |
|---|---|
| `contacts` | Form submissions from website visitors |
| `admins` | Admin users (hashed passwords with bcryptjs) |
| `stats` | Homepage stats (projects, clients, etc.) |

### Upgrading to PostgreSQL (production)

Replace `src/db.js` with a `pg` implementation. The `all()`, `get()`, and `run()` interfaces stay the same — only the adapter changes.

```bash
npm install pg
```

---

## 🔌 API Reference

### Public

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Server status |
| GET | `/api/stats` | Homepage stats |
| POST | `/api/contact` | Submit inquiry |

**POST /api/contact body:**
```json
{
  "name": "Rahul Sharma",
  "email": "rahul@example.com",
  "service": "Web Development",
  "message": "I need a portfolio website..."
}
```

### Admin (requires session cookie)

| Method | Endpoint | Description |
|---|---|---|
| POST | `/admin/login` | Login |
| POST | `/admin/logout` | Logout |
| GET | `/admin/me` | Current user |
| GET | `/admin/contacts` | List inquiries (paginated, filterable) |
| GET | `/admin/contacts/:id` | Single inquiry |
| PATCH | `/admin/contacts/:id` | Update status |
| DELETE | `/admin/contacts/:id` | Delete |
| GET | `/admin/stats/overview` | Dashboard stats |
| PATCH | `/admin/stats` | Update homepage stats |

---

## 🚢 Deploy to Render.com (Free)

### One-time setup

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USER/pradex-technologies.git
   git push -u origin main
   ```

2. **Create Web Service on Render**
   - Go to [render.com](https://render.com) → **New** → **Web Service**
   - Connect your GitHub repo
   - Render detects `render.yaml` automatically

3. **Add Environment Variables** in Render Dashboard → Environment:
   ```
   ADMIN_PASSWORD   = your_secure_password
   EMAIL_USER       = your_gmail@gmail.com
   EMAIL_PASS       = your_app_password
   OWNER_EMAIL      = pradeep@pradextech.com
   ```

4. Click **Deploy** → your site is live in ~2 minutes

> **Free tier note:** The server sleeps after 15 min of inactivity and takes ~30s to wake up. Upgrade to Starter ($7/mo) for always-on.

### Custom domain

In Render Dashboard → Settings → Custom Domains → add `pradextech.com`
Then update your domain's DNS with the CNAME Render gives you.

---

## 📁 Project Structure

```
pradex-technologies/
├── server.js              ← Express app (entry point)
├── package.json
├── render.yaml            ← Render.com deploy config
├── .env.example           ← Copy to .env and fill in
├── .gitignore
├── db/
│   └── pradex.sqlite      ← Auto-created on first run (gitignored)
├── src/
│   ├── db.js              ← Database module (sql.js / SQLite)
│   ├── auth.js            ← Session auth + admin seeding
│   └── email.js           ← Nodemailer email service
└── public/
    ├── index.html         ← Main website (frontend)
    └── admin.html         ← Admin dashboard SPA
```

---

## 🔒 Security Features

- **Helmet.js** — sets secure HTTP headers
- **Rate limiting** — 5 contact submissions / 15 min; 10 login attempts / 15 min
- **bcryptjs** — admin passwords hashed with 12 rounds
- **HttpOnly cookies** — session tokens not accessible to JS
- **Server-side validation** — all inputs validated before DB write
- **Input sanitization** — XSS protection in admin dashboard

---

## 🔧 Changing Admin Password

Edit `.env`:
```env
ADMIN_PASSWORD=your_new_secure_password
```
Then restart the server. The admin user is re-seeded on boot if not already present.

To reset manually, delete `db/pradex.sqlite` and restart — the DB will be recreated with the new password.

---

Built with ❤️ for **Pradeep Jakhar** — [pradextech.com](https://pradextech.com)
