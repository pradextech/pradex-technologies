/**
 * Pradex Technologies — Production Server v2
 * Node.js + Express
 *
 * Features:
 *   - SQLite database (sql.js)
 *   - Contact form with server-side validation
 *   - Email notifications (owner + client confirmation)
 *   - Admin dashboard API (session auth)
 *   - Rate limiting, helmet security headers
 *   - Serves static frontend
 */

require('dotenv').config();
const path    = require('path');
const express = require('express');
const helmet  = require('helmet');
const rateLimit = require('express-rate-limit');

const { getDb, all, get, run }                    = require('./src/db');
const { sendOwnerNotification, sendClientConfirmation } = require('./src/email');
const { parseCookies, requireAdmin, handleLogin, handleLogout, seedAdmin } = require('./src/auth');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── SECURITY MIDDLEWARE ──────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: false, // allow Google Fonts etc. from index.html
}));
app.use(express.json({ limit: '16kb' }));
app.use(express.urlencoded({ extended: true, limit: '16kb' }));
app.use(parseCookies);

const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 5,
  message: { success: false, errors: ['Too many submissions. Please try again in 15 minutes.'] },
  standardHeaders: true,
  legacyHeaders: false,
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { success: false, error: 'Too many login attempts. Try again later.' },
});

// ── STATIC FILES ─────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

// ── HELPERS ──────────────────────────────────────────────────
function validateContact(body) {
  const errors = [];
  if (!body.name || body.name.trim().length < 2) errors.push('Name must be at least 2 characters.');
  if (!body.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email.trim())) errors.push('A valid email address is required.');
  if (!body.message || body.message.trim().length < 10) errors.push('Message must be at least 10 characters.');
  return errors;
}

function generateId() {
  return `PRX-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

// ── PUBLIC ROUTES ─────────────────────────────────────────────

app.get('/health', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime(), version: '2.0.0', ts: new Date().toISOString() });
});

app.get('/api/stats', (req, res) => {
  const rows = all('SELECT key, value FROM stats');
  const data = Object.fromEntries(rows.map(r => [r.key, r.value]));
  res.json({ success: true, data });
});

app.post('/api/contact', contactLimiter, async (req, res) => {
  const errors = validateContact(req.body);
  if (errors.length) return res.status(400).json({ success: false, errors });

  const inquiry = {
    id:      generateId(),
    name:    req.body.name.trim(),
    email:   req.body.email.trim().toLowerCase(),
    service: (req.body.service || '').trim() || 'Not specified',
    message: req.body.message.trim(),
    ip:      req.headers['x-forwarded-for'] || req.socket.remoteAddress,
  };

  const saved = run(
    'INSERT INTO contacts (id, name, email, service, message, ip) VALUES (?, ?, ?, ?, ?, ?)',
    [inquiry.id, inquiry.name, inquiry.email, inquiry.service, inquiry.message, inquiry.ip]
  );

  if (!saved) return res.status(500).json({ success: false, errors: ['Failed to save inquiry. Please try again.'] });

  // Send emails (non-blocking — don't fail the request if email fails)
  Promise.allSettled([
    sendOwnerNotification(inquiry),
    sendClientConfirmation(inquiry),
  ]).then(results => {
    results.forEach((r, i) => {
      if (r.status === 'rejected') console.error(`[Email ${i}] failed:`, r.reason?.message);
    });
  });

  console.log(`[Contact] New inquiry saved: ${inquiry.id} from ${inquiry.name} <${inquiry.email}>`);

  return res.status(201).json({
    success: true,
    message: "Thank you! We've received your message and will respond within 24 hours.",
    id: inquiry.id,
  });
});

// ── ADMIN AUTH ROUTES ─────────────────────────────────────────

app.post('/admin/login',  loginLimiter, handleLogin);
app.post('/admin/logout', handleLogout);

app.get('/admin/me', parseCookies, requireAdmin, (req, res) => {
  res.json({ success: true, username: req.adminUser });
});

// ── ADMIN DATA ROUTES (all protected) ─────────────────────────

app.get('/admin/contacts', requireAdmin, (req, res) => {
  const { status, page = 1, limit = 20, search = '' } = req.query;
  const pg  = Math.max(1, parseInt(page));
  const lim = Math.min(100, Math.max(1, parseInt(limit)));
  const offset = (pg - 1) * lim;

  let where  = [];
  let params = [];

  if (status) { where.push('status = ?'); params.push(status); }
  if (search) {
    where.push('(name LIKE ? OR email LIKE ? OR message LIKE ?)');
    const s = `%${search}%`;
    params.push(s, s, s);
  }

  const whereClause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const countRow    = get(`SELECT COUNT(*) as total FROM contacts ${whereClause}`, params);
  const total       = countRow?.total ?? 0;

  const rows = all(
    `SELECT * FROM contacts ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    [...params, lim, offset]
  );

  res.json({
    success: true, total, page: pg, limit: lim,
    pages: Math.ceil(total / lim), data: rows,
  });
});

app.get('/admin/contacts/:id', requireAdmin, (req, res) => {
  const row = get('SELECT * FROM contacts WHERE id = ?', [req.params.id]);
  if (!row) return res.status(404).json({ success: false, error: 'Not found.' });
  res.json({ success: true, data: row });
});

app.patch('/admin/contacts/:id', requireAdmin, (req, res) => {
  const valid = ['new', 'read', 'replied'];
  if (!valid.includes(req.body.status)) {
    return res.status(400).json({ success: false, error: 'Invalid status.' });
  }
  const ok = run(
    "UPDATE contacts SET status = ?, updated_at = datetime('now') WHERE id = ?",
    [req.body.status, req.params.id]
  );
  if (!ok) return res.status(404).json({ success: false, error: 'Not found.' });
  res.json({ success: true });
});

app.delete('/admin/contacts/:id', requireAdmin, (req, res) => {
  run('DELETE FROM contacts WHERE id = ?', [req.params.id]);
  res.json({ success: true });
});

app.get('/admin/stats/overview', requireAdmin, (req, res) => {
  const total   = get('SELECT COUNT(*) as c FROM contacts')?.c ?? 0;
  const newC    = get("SELECT COUNT(*) as c FROM contacts WHERE status = 'new'")?.c ?? 0;
  const read    = get("SELECT COUNT(*) as c FROM contacts WHERE status = 'read'")?.c ?? 0;
  const replied = get("SELECT COUNT(*) as c FROM contacts WHERE status = 'replied'")?.c ?? 0;
  const today   = get("SELECT COUNT(*) as c FROM contacts WHERE date(created_at) = date('now')")?.c ?? 0;
  const week    = get("SELECT COUNT(*) as c FROM contacts WHERE created_at >= datetime('now', '-7 days')")?.c ?? 0;

  // Most requested service
  const topService = get(`
    SELECT service, COUNT(*) as count FROM contacts
    GROUP BY service ORDER BY count DESC LIMIT 1
  `);

  res.json({ success: true, data: { total, new: newC, read, replied, today, week, topService } });
});

app.patch('/admin/stats', requireAdmin, (req, res) => {
  const allowed = ['projects', 'clients', 'experience', 'satisfaction'];
  const updates = Object.entries(req.body).filter(([k]) => allowed.includes(k));
  updates.forEach(([k, v]) => run('UPDATE stats SET value = ? WHERE key = ?', [parseInt(v), k]));
  res.json({ success: true });
});

// ── ADMIN DASHBOARD (served as SPA) ──────────────────────────
app.get('/admin*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// ── CATCH-ALL (SPA) ──────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── ERROR HANDLER ─────────────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error('[Error]', err.message);
  res.status(500).json({ success: false, error: 'Internal Server Error' });
});

// ── BOOT ──────────────────────────────────────────────────────
async function boot() {
  await getDb();
  await seedAdmin();

  app.listen(PORT, () => {
    console.log(`
  ╔═══════════════════════════════════════════╗
  ║    Pradex Technologies — Server v2.0      ║
  ║    http://localhost:${PORT}                  ║
  ╠═══════════════════════════════════════════╣
  ║  Frontend  →  http://localhost:${PORT}/       ║
  ║  Admin     →  http://localhost:${PORT}/admin  ║
  ║  Health    →  http://localhost:${PORT}/health ║
  ╚═══════════════════════════════════════════╝
    `);
  });
}

boot().catch(err => { console.error('Boot failed:', err); process.exit(1); });

module.exports = app;
