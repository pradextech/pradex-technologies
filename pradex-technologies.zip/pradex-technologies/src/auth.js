/**
 * Auth middleware — simple session-based admin auth
 * Uses a signed cookie for session management.
 * No extra dependencies needed.
 */

const crypto  = require('crypto');
const bcrypt  = require('bcryptjs');
const { get, run } = require('./db');

const SESSION_STORE = new Map(); // sessionId → { username, expiresAt }
const SESSION_TTL   = 8 * 60 * 60 * 1000; // 8 hours

// ── Session helpers ──────────────────────────────────────────
function createSession(username) {
  const id = crypto.randomBytes(32).toString('hex');
  SESSION_STORE.set(id, {
    username,
    expiresAt: Date.now() + SESSION_TTL,
  });
  return id;
}

function getSession(req) {
  const sid = req.cookies?.pradex_sid;
  if (!sid) return null;
  const session = SESSION_STORE.get(sid);
  if (!session) return null;
  if (session.expiresAt < Date.now()) {
    SESSION_STORE.delete(sid);
    return null;
  }
  return session;
}

function destroySession(req) {
  const sid = req.cookies?.pradex_sid;
  if (sid) SESSION_STORE.delete(sid);
}

// Clean up expired sessions every hour
setInterval(() => {
  const now = Date.now();
  for (const [id, s] of SESSION_STORE.entries()) {
    if (s.expiresAt < now) SESSION_STORE.delete(id);
  }
}, 60 * 60 * 1000);

// ── Cookie parser (lightweight, no dependency) ───────────────
function parseCookies(req, res, next) {
  req.cookies = {};
  const header = req.headers.cookie;
  if (header) {
    header.split(';').forEach(part => {
      const [k, ...v] = part.trim().split('=');
      req.cookies[k.trim()] = decodeURIComponent(v.join('='));
    });
  }
  next();
}

// ── Route: POST /admin/login ─────────────────────────────────
async function handleLogin(req, res) {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, error: 'Username and password required.' });
  }

  const admin = get('SELECT * FROM admins WHERE username = ?', [username]);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Invalid credentials.' });
  }

  const ok = await bcrypt.compare(password, admin.password_hash);
  if (!ok) {
    return res.status(401).json({ success: false, error: 'Invalid credentials.' });
  }

  const sid = createSession(username);
  res.setHeader('Set-Cookie', `pradex_sid=${sid}; HttpOnly; Path=/; Max-Age=${SESSION_TTL / 1000}; SameSite=Strict`);
  return res.json({ success: true, username });
}

// ── Route: POST /admin/logout ────────────────────────────────
function handleLogout(req, res) {
  destroySession(req);
  res.clearCookie('pradex_sid');
  res.json({ success: true });
}

// ── Middleware: protect admin routes ─────────────────────────
function requireAdmin(req, res, next) {
  const session = getSession(req);
  if (!session) {
    return res.status(401).json({ success: false, error: 'Unauthorized. Please log in.' });
  }
  req.adminUser = session.username;
  next();
}

// ── Seed default admin (run at startup) ──────────────────────
async function seedAdmin() {
  const existing = get('SELECT id FROM admins WHERE username = ?', ['admin']);
  if (!existing) {
    const pass = process.env.ADMIN_PASSWORD || 'pradex@2025';
    const hash = await bcrypt.hash(pass, 12);
    run('INSERT INTO admins (username, password_hash) VALUES (?, ?)', ['admin', hash]);
    console.log(`[Auth] Default admin created. Username: admin  Password: ${pass}`);
    console.log('[Auth] ⚠️  Change ADMIN_PASSWORD in .env before going live!');
  }
}

module.exports = { parseCookies, requireAdmin, handleLogin, handleLogout, seedAdmin };
