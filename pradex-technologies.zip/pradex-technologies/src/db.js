/**
 * Database module — sql.js (pure-JS SQLite, no native build needed)
 * In production swap to better-sqlite3 or pg (PostgreSQL) by changing
 * only this file — the rest of the app stays the same.
 */

const path = require('path');
const fs   = require('fs');

let db;

async function getDb() {
  if (db) return db;

  const initSqlJs = require('../node_modules/sql.js');
  const SQL = await initSqlJs();

  // Support Render.com persistent disk or local db/ folder
  const dbDir  = process.env.DB_PATH || path.join(__dirname, '..', 'db');
  if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
  const dbPath = path.join(dbDir, 'pradex.sqlite');

  // Load existing DB from disk, or create new
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  // Save helper — persists in-memory DB to disk
  db.save = function () {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  };

  createSchema();
  return db;
}

function createSchema() {
  db.run(`
    CREATE TABLE IF NOT EXISTS contacts (
      id          TEXT PRIMARY KEY,
      name        TEXT NOT NULL,
      email       TEXT NOT NULL,
      service     TEXT,
      message     TEXT NOT NULL,
      status      TEXT DEFAULT 'new',
      ip          TEXT,
      created_at  TEXT DEFAULT (datetime('now')),
      updated_at  TEXT
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS admins (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      username      TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at    TEXT DEFAULT (datetime('now'))
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS stats (
      key   TEXT PRIMARY KEY,
      value INTEGER NOT NULL
    );
  `);

  // Seed default stats
  const rows = db.exec("SELECT COUNT(*) as c FROM stats")[0];
  if (!rows || rows.values[0][0] === 0) {
    db.run(`INSERT OR IGNORE INTO stats VALUES ('projects', 50)`);
    db.run(`INSERT OR IGNORE INTO stats VALUES ('clients', 30)`);
    db.run(`INSERT OR IGNORE INTO stats VALUES ('experience', 5)`);
    db.run(`INSERT OR IGNORE INTO stats VALUES ('satisfaction', 99)`);
    db.save();
  }

  console.log('[DB] Schema ready');
}

// ── Query helpers ─────────────────────────────────────────────
function all(sql, params = []) {
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
    return rows;
  } catch (e) {
    console.error('[DB] all() error:', e.message, sql);
    return [];
  }
}

function get(sql, params = []) {
  return all(sql, params)[0] || null;
}

function run(sql, params = []) {
  try {
    db.run(sql, params);
    db.save();
    return true;
  } catch (e) {
    console.error('[DB] run() error:', e.message);
    return false;
  }
}

module.exports = { getDb, all, get, run };
