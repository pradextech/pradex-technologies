/**
 * Email service — Nodemailer
 * Supports Gmail SMTP (default) and any SMTP provider.
 *
 * To use Gmail:
 *   1. Enable 2FA on your Google account
 *   2. Generate an App Password at: https://myaccount.google.com/apppasswords
 *   3. Set EMAIL_USER and EMAIL_PASS in your .env file
 */

const nodemailer = require('nodemailer');

function createTransport() {
  const { EMAIL_HOST, EMAIL_PORT, EMAIL_USER, EMAIL_PASS, EMAIL_SECURE } = process.env;

  // If no credentials configured, use Ethereal (dev preview only)
  if (!EMAIL_USER || !EMAIL_PASS) {
    console.warn('[Email] No credentials set — emails will be logged to console only.');
    return null;
  }

  return nodemailer.createTransport({
    host:   EMAIL_HOST  || 'smtp.gmail.com',
    port:   parseInt(EMAIL_PORT || '465'),
    secure: EMAIL_SECURE !== 'false', // true for 465, false for 587
    auth: {
      user: EMAIL_USER,
      pass: EMAIL_PASS,
    },
  });
}

const transport = createTransport();

/**
 * Send notification to site owner when a new inquiry arrives.
 */
async function sendOwnerNotification(inquiry) {
  const { OWNER_EMAIL, SITE_NAME } = process.env;
  const to = OWNER_EMAIL || process.env.EMAIL_USER;
  const siteName = SITE_NAME || 'Pradex Technologies';

  if (!transport) {
    console.log(`\n[Email — PREVIEW] New inquiry notification:\n  From: ${inquiry.name} <${inquiry.email}>\n  Service: ${inquiry.service}\n  Message: ${inquiry.message}\n  ID: ${inquiry.id}\n`);
    return { previewMode: true };
  }

  const html = `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <style>
      body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f4f8; margin: 0; padding: 32px; }
      .card { background: #fff; border-radius: 12px; max-width: 560px; margin: 0 auto; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
      .header { background: linear-gradient(135deg, #0057ff, #00c8ff); padding: 32px; color: #fff; }
      .header h1 { margin: 0; font-size: 1.4rem; font-weight: 700; }
      .header p { margin: 6px 0 0; opacity: 0.85; font-size: 0.9rem; }
      .body { padding: 32px; }
      .field { margin-bottom: 20px; }
      .label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.08em; color: #7a8faa; font-weight: 600; margin-bottom: 4px; }
      .value { font-size: 0.97rem; color: #1a2a3a; line-height: 1.6; }
      .id-badge { display: inline-block; background: #eef2ff; color: #0057ff; font-size: 0.78rem; font-family: monospace; padding: 4px 12px; border-radius: 100px; margin-top: 8px; }
      .footer { border-top: 1px solid #e8ecf0; padding: 20px 32px; font-size: 0.8rem; color: #7a8faa; }
      .cta { display: inline-block; margin-top: 24px; background: linear-gradient(135deg, #0057ff, #00c8ff); color: #fff; text-decoration: none; padding: 12px 28px; border-radius: 8px; font-size: 0.9rem; font-weight: 600; }
    </style>
  </head>
  <body>
    <div class="card">
      <div class="header">
        <h1>📬 New Project Inquiry</h1>
        <p>${siteName} · ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST</p>
      </div>
      <div class="body">
        <div class="field">
          <div class="label">Name</div>
          <div class="value">${inquiry.name}</div>
        </div>
        <div class="field">
          <div class="label">Email</div>
          <div class="value"><a href="mailto:${inquiry.email}" style="color:#0057ff;">${inquiry.email}</a></div>
        </div>
        <div class="field">
          <div class="label">Service Requested</div>
          <div class="value">${inquiry.service || 'Not specified'}</div>
        </div>
        <div class="field">
          <div class="label">Project Brief</div>
          <div class="value" style="background:#f8fafc; padding:16px; border-radius:8px; border-left:3px solid #00c8ff;">${inquiry.message.replace(/\n/g, '<br>')}</div>
        </div>
        <div class="field">
          <div class="label">Inquiry ID</div>
          <span class="id-badge">${inquiry.id}</span>
        </div>
        <a class="cta" href="mailto:${inquiry.email}?subject=Re: Your inquiry to ${siteName}">Reply to ${inquiry.name} →</a>
      </div>
      <div class="footer">
        This email was sent automatically by the ${siteName} contact form.<br>
        Submitted from IP: ${inquiry.ip || 'unknown'}
      </div>
    </div>
  </body>
  </html>`;

  return transport.sendMail({
    from:    `"${siteName}" <${process.env.EMAIL_USER}>`,
    to,
    subject: `New Inquiry: ${inquiry.service || 'General'} — ${inquiry.name}`,
    html,
    text: `New inquiry from ${inquiry.name} <${inquiry.email}>\nService: ${inquiry.service}\n\n${inquiry.message}\n\nID: ${inquiry.id}`,
  });
}

/**
 * Send confirmation to the person who submitted the form.
 */
async function sendClientConfirmation(inquiry) {
  const { SITE_NAME } = process.env;
  const siteName = SITE_NAME || 'Pradex Technologies';

  if (!transport) return { previewMode: true };

  const html = `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8" />
    <style>
      body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f4f8; margin: 0; padding: 32px; }
      .card { background: #fff; border-radius: 12px; max-width: 560px; margin: 0 auto; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
      .header { background: linear-gradient(135deg, #0057ff, #00c8ff); padding: 40px 32px; color: #fff; text-align: center; }
      .header h1 { margin: 0; font-size: 2rem; }
      .header p { margin: 8px 0 0; opacity: 0.9; font-size: 1rem; }
      .body { padding: 36px 32px; text-align: center; }
      .body h2 { color: #1a2a3a; font-size: 1.3rem; margin-bottom: 16px; }
      .body p { color: #4a6070; line-height: 1.7; margin-bottom: 16px; }
      .ref { display: inline-block; background: #eef2ff; color: #0057ff; font-family: monospace; font-size: 0.85rem; padding: 8px 20px; border-radius: 100px; margin: 16px 0; }
      .footer { border-top: 1px solid #e8ecf0; padding: 20px 32px; font-size: 0.8rem; color: #7a8faa; text-align: center; }
      a { color: #0057ff; }
    </style>
  </head>
  <body>
    <div class="card">
      <div class="header">
        <h1>🚀</h1>
        <p>Message received!</p>
      </div>
      <div class="body">
        <h2>Thanks, ${inquiry.name}!</h2>
        <p>We've received your inquiry about <strong>${inquiry.service || 'your project'}</strong> and will get back to you within <strong>24 hours</strong> on business days.</p>
        <p>Your reference number:</p>
        <div class="ref">${inquiry.id}</div>
        <p style="font-size:0.9rem;">In the meantime, feel free to connect with us on <a href="https://www.linkedin.com/in/pradeepjakhar/">LinkedIn</a> or explore our work at <a href="https://pradextech.com">pradextech.com</a>.</p>
      </div>
      <div class="footer">
        ${siteName} · Jaipur, Rajasthan, India<br>
        <a href="mailto:pradeep@pradextech.com">pradeep@pradextech.com</a>
      </div>
    </div>
  </body>
  </html>`;

  return transport.sendMail({
    from:    `"${siteName}" <${process.env.EMAIL_USER}>`,
    to:      inquiry.email,
    subject: `We got your message, ${inquiry.name.split(' ')[0]}! — ${siteName}`,
    html,
    text: `Hi ${inquiry.name},\n\nThank you for reaching out to ${siteName}!\n\nWe've received your inquiry and will respond within 24 hours.\n\nReference: ${inquiry.id}\n\nBest,\nPradeep Jakhar\nFounder, ${siteName}`,
  });
}

module.exports = { sendOwnerNotification, sendClientConfirmation };
